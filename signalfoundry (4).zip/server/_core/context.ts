import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { User } from "../../drizzle/schema";
import { ANONYMOUS_SESSION_COOKIE, getOrCreateAnonymousAccess, type AnonymousAccess } from "../db";
import { getSessionCookieOptions } from "./cookies";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
  anonymous: AnonymousAccess | null;
};

function readCookie(header: string | undefined, name: string) {
  if (!header) return undefined;
  const match = header.split(";").map(part => part.trim()).find(part => part.startsWith(`${name}=`));
  return match ? decodeURIComponent(match.slice(name.length + 1)) : undefined;
}

export async function createContext(opts: CreateExpressContextOptions): Promise<TrpcContext> {
  try {
    const anonymous = await getOrCreateAnonymousAccess(readCookie(opts.req.headers.cookie, ANONYMOUS_SESSION_COOKIE));
    if (anonymous.created) {
      opts.res.cookie(ANONYMOUS_SESSION_COOKIE, anonymous.token, { ...getSessionCookieOptions(opts.req), expires: anonymous.expiresAt });
    }
    return { req: opts.req, res: opts.res, user: anonymous.user, anonymous };
  } catch (error) {
    console.error("[Session] Anonymous session bootstrap failed:", error instanceof Error ? error.message : "unknown error");
    return { req: opts.req, res: opts.res, user: null, anonymous: null };
  }
}
