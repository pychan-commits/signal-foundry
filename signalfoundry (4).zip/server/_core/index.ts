import "dotenv/config";
import express from "express";
import { createServer } from "http";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { publicPlatformScript } from "./publicConfig";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { ANONYMOUS_SESSION_COOKIE, getOrCreateAnonymousAccess } from "../db";
import { createImageKitUploadAuth, imageKitUploadSchema } from "../imagekit";
import { getSessionCookieOptions } from "./cookies";

async function startServer() {
  const app = express();
  const server = createServer(app);
  // Keep JSON/urlencoded payloads bounded; attachments use a separately signed provider flow.
  app.use(express.json({ limit: "2mb" }));
  app.use(express.urlencoded({ limit: "2mb", extended: true }));
  app.get("/api/health", (_req, res) => res.json({ status: "ok" }));
  app.get("/api/platform/config.js", (_req, res) => {
    res.set("Cache-Control", "no-store").type("application/javascript").send(publicPlatformScript());
  });
  app.post("/api/uploads/imagekit", async (req, res) => {
    try {
      const raw = req.headers.cookie?.split(";").map(value => value.trim()).find(value => value.startsWith(`${ANONYMOUS_SESSION_COOKIE}=`))?.slice(ANONYMOUS_SESSION_COOKIE.length + 1);
      const access = await getOrCreateAnonymousAccess(raw ? decodeURIComponent(raw) : undefined);
      if (access.created) res.cookie(ANONYMOUS_SESSION_COOKIE, access.token, { ...getSessionCookieOptions(req), expires: access.expiresAt });
      const input = imageKitUploadSchema.parse(req.body);
      const auth = await createImageKitUploadAuth(input, access.user.id);
      res.json(auth);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Attachment authorization failed.";
      res.status(message.includes("not configured") ? 503 : 400).json({ error: message });
    }
  });
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const port = Number(process.env.PORT || "3000");
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("Invalid PORT");
  server.on("error", error => { console.error("Server failed:", error.message); process.exit(1); });
  server.listen(port, "0.0.0.0", () => console.log(`Server listening on port ${port}`));
}

startServer().catch(error => { console.error(error); process.exit(1); });
