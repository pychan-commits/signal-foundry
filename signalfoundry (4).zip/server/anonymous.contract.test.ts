import { describe, expect, it } from "vitest";
import { imageKitStatus, imageKitUploadSchema } from "./imagekit";
import { PLAN_CONFIG, stripeTestConfiguration } from "./plan-config";
import { appRouter } from "./routers";

describe("anonymous Phase 1 contracts", () => {
  it("exposes session info without an account identity", async () => {
    const caller = appRouter.createCaller({
      req: {} as any,
      res: {} as any,
      user: null,
      anonymous: null,
    });
    await expect(caller.session.info()).resolves.toEqual({ ready: false, privacyNoticeVersion: "2026-10-v1" });
  });

  it("keeps Team planned and Stripe disabled without test credentials", () => {
    expect(PLAN_CONFIG.team.planned).toBe(true);
    expect(PLAN_CONFIG.team.founderCheckout).toBe(false);
    const stripe = stripeTestConfiguration();
    expect(stripe.enabled).toBe(false);
  });

  it("enforces ImageKit file types and the 10 MB limit", () => {
    expect(imageKitStatus().maxFileSize).toBe(10 * 1024 * 1024);
    expect(() => imageKitUploadSchema.parse({ workspaceId: 1, signalId: 1, fileName: "notes.exe", mimeType: "application/octet-stream", fileSize: 12 })).toThrow();
    expect(() => imageKitUploadSchema.parse({ workspaceId: 1, signalId: 1, fileName: "research.pdf", mimeType: "application/pdf", fileSize: 10 * 1024 * 1024 })).not.toThrow();
    expect(() => imageKitUploadSchema.parse({ workspaceId: 1, signalId: 1, fileName: "large.pdf", mimeType: "application/pdf", fileSize: 10 * 1024 * 1024 + 1 })).toThrow();
  });
});
