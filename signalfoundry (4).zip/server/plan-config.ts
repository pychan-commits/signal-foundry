export const PLAN_CONFIG = {
  free: { label: "Free", price: "$0", maxWorkspaces: 1, founderCheckout: false },
  founder: { label: "Founder", price: "$19/month", maxWorkspaces: 10, founderCheckout: true },
  team: { label: "Team", price: "$49/month", maxWorkspaces: 0, founderCheckout: false, planned: true },
} as const;

export function stripeTestConfiguration() {
  const secret = process.env.STRIPE_SECRET_KEY || "";
  const price = process.env.STRIPE_PRICE_FOUNDER || "";
  const looksLive = secret.startsWith("sk_live_") || price.startsWith("price_live_");
  return { configured: Boolean(secret && price), looksLive, enabled: Boolean(secret && price) && !looksLive };
}
