import { z } from "zod";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import {
  acknowledgePrivacyNotice,
  chooseTestPlan,
  createWorkspaceForUser,
  deleteWorkspaceForUser,
  getWorkspaceState,
  getAnonymousSessionState,
  importSignals,
  mutateEntity,
  resetAnonymousWorkspace,
  setCurrentWorkspace,
  updateWorkspaceSettings,
} from "./db";
import { PLAN_CONFIG, stripeTestConfiguration } from "./plan-config";
import { imageKitStatus } from "./imagekit";

const entitySchema = z.enum(["signal", "problem", "opportunity", "experiment", "decision", "segment", "customer", "tag", "note", "member", "savedView"]);

export const appRouter = router({
  system: systemRouter,
  session: router({
    info: publicProcedure.query(({ ctx }) => {
      if (!ctx.anonymous) return { ready: false, privacyNoticeVersion: "2026-10-v1" as const };
      return { ready: true, publicId: ctx.anonymous.publicId, created: ctx.anonymous.created, privacyNoticeVersion: "2026-10-v1" as const };
    }),
    acknowledgePrivacy: protectedProcedure
      .input(z.object({ acknowledged: z.boolean(), analyticsConsent: z.enum(["unknown", "granted", "withdrawn"]).optional() }))
      .mutation(({ ctx, input }) => acknowledgePrivacyNotice(ctx.anonymous!.sessionId, input.acknowledged, input.analyticsConsent)),
    state: protectedProcedure.query(({ ctx }) => getAnonymousSessionState(ctx.anonymous!.sessionId)),
    reset: protectedProcedure
      .input(z.object({ confirmation: z.literal("RESET WORKSPACE") }))
      .mutation(({ ctx, input }) => resetAnonymousWorkspace(ctx.user!, ctx.anonymous!.sessionId, input.confirmation)),
  }),
  workspace: router({
    state: protectedProcedure
      .input(z.object({ workspaceId: z.number().int().positive().optional() }).optional())
      .query(({ ctx, input }) => getWorkspaceState(ctx.user!, input?.workspaceId)),
    create: protectedProcedure
      .input(z.object({ name: z.string().trim().min(2, "Enter a workspace name."), seedDemo: z.boolean().optional() }))
      .mutation(async ({ ctx, input }) => ({ workspaceId: await createWorkspaceForUser(ctx.user!, input.name, input.seedDemo ?? false, ctx.anonymous!.sessionId) })),
    delete: protectedProcedure
      .input(z.object({ workspaceId: z.number().int().positive(), confirmationName: z.string().trim().min(1) }))
      .mutation(({ ctx, input }) => deleteWorkspaceForUser(ctx.user!, input.workspaceId, input.confirmationName)),
    switch: protectedProcedure
      .input(z.object({ workspaceId: z.number().int().positive() }))
      .mutation(async ({ ctx, input }) => { await setCurrentWorkspace(ctx.user!.id, input.workspaceId); return { success: true }; }),
    updateSettings: protectedProcedure
      .input(z.object({ workspaceId: z.number().int().positive(), name: z.string().trim().min(2).optional(), scoringWeights: z.record(z.string(), z.number()).optional() }))
      .mutation(({ ctx, input }) => updateWorkspaceSettings(ctx.user!, input.workspaceId, input)),
  }),
  data: router({
    mutate: protectedProcedure
      .input(z.object({ workspaceId: z.number().int().positive(), entity: entitySchema, action: z.enum(["create", "update", "delete"]), payload: z.record(z.string(), z.unknown()) }))
      .mutation(({ ctx, input }) => mutateEntity(ctx.user!, input.workspaceId, input.entity, input.action, input.payload)),
    importSignals: protectedProcedure
      .input(z.object({ workspaceId: z.number().int().positive(), rows: z.array(z.record(z.string(), z.unknown())).min(1).max(100) }))
      .mutation(({ ctx, input }) => importSignals(ctx.user!, input.workspaceId, input.rows)),
  }),
  billing: router({
    plans: publicProcedure.query(() => ({ plans: PLAN_CONFIG, stripe: stripeTestConfiguration() })),
    chooseTestPlan: protectedProcedure
      .input(z.object({ workspaceId: z.number().int().positive(), plan: z.enum(["free", "founder", "team"]) }))
      .mutation(({ ctx, input }) => chooseTestPlan(ctx.user!, input.workspaceId, input.plan)),
  }),
  integrations: router({
    status: publicProcedure.query(() => ({ imageKit: imageKitStatus() })),
  }),
});

export type AppRouter = typeof appRouter;
