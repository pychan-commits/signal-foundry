import { and, desc, eq, gt, inArray, isNull } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { createHash, randomBytes, randomUUID, scrypt, timingSafeEqual } from "crypto";
import { promisify } from "util";
import {
  anonymousSessions,
  customers,
  customerSegments,
  decisions,
  experiments,
  InsertUser,
  notes,
  opportunities,
  problemSignals,
  problems,
  savedViews,
  signalTags,
  signals,
  subscriptions,
  tags,
  userSessions,
  users,
  User,
  workspaces,
  workspaceMembers,
} from "../drizzle/schema";
import { ENV } from "./_core/env";
import { PLAN_CONFIG, stripeTestConfiguration } from "./plan-config";

const scryptAsync = promisify(scrypt);
export const EMAIL_SESSION_COOKIE = "sf_session";
export const ANONYMOUS_SESSION_COOKIE = "sf_anon";
export const PRIVACY_NOTICE_VERSION = "2026-10-v1";
export const DEFAULT_WEIGHTS = { frequency: 25, severity: 25, willingnessToPay: 20, strategicFit: 20, effort: 10 };

type EntityName =
  | "signal"
  | "problem"
  | "opportunity"
  | "experiment"
  | "decision"
  | "segment"
  | "customer"
  | "tag"
  | "note"
  | "member"
  | "savedView";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

function requiredDb(db: Awaited<ReturnType<typeof getDb>>) {
  if (!db) throw new Error("Database is not available");
  return db;
}

function normalizeEmail(email: string) {
  return email.trim().toLowerCase();
}

function toText(value: unknown, fallback = "") {
  return typeof value === "string" ? value.trim() : fallback;
}

function toInt(value: unknown, fallback = 0) {
  const number = Number(value);
  return Number.isFinite(number) ? Math.round(number) : fallback;
}

function score(value: unknown, fallback = 3) {
  return Math.max(1, Math.min(5, toInt(value, fallback)));
}

function hashToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

export type AnonymousAccess = { user: User; sessionId: number; publicId: string; token: string; expiresAt: Date; created: boolean };

export async function getOrCreateAnonymousAccess(rawToken?: string): Promise<AnonymousAccess> {
  const db = requiredDb(await getDb());
  const now = new Date();
  if (rawToken) {
    const found = await db.select().from(anonymousSessions).where(and(eq(anonymousSessions.tokenHash, hashToken(rawToken)), gt(anonymousSessions.expiresAt, now))).limit(1);
    if (found[0]) {
      await db.update(anonymousSessions).set({ lastSeenAt: now }).where(eq(anonymousSessions.id, found[0].id));
      const user = await getUserByOpenId(`anonymous:${found[0].publicId}`);
      if (user) return { user, sessionId: found[0].id, publicId: found[0].publicId, token: rawToken, expiresAt: found[0].expiresAt, created: false };
    }
  }
  const token = randomBytes(32).toString("base64url");
  const publicId = randomUUID();
  const expiresAt = new Date(Date.now() + 1000 * 60 * 60 * 24 * 90);
  const sessionId = await insertId(db, anonymousSessions, { publicId, tokenHash: hashToken(token), noticeVersion: PRIVACY_NOTICE_VERSION, expiresAt, lastSeenAt: now });
  const userId = await insertId(db, users, { openId: `anonymous:${publicId}`, name: "Anonymous workspace", loginMethod: "anonymous", role: "user", lastSignedIn: now });
  const user = (await getUserById(userId))!;
  await createWorkspaceForUser(user, "Northstar Notes", true, sessionId);
  return { user, sessionId, publicId, token, expiresAt, created: true };
}

export async function acknowledgePrivacyNotice(sessionId: number, acknowledged: boolean, analyticsConsent?: "unknown" | "granted" | "withdrawn") {
  const db = requiredDb(await getDb());
  const update: Record<string, unknown> = { noticeAcknowledgedAt: acknowledged ? new Date() : null };
  if (analyticsConsent) { update.analyticsConsent = analyticsConsent; update.analyticsConsentAt = new Date(); }
  await db.update(anonymousSessions).set(update as any).where(eq(anonymousSessions.id, sessionId));
  return { success: true } as const;
}

export async function getAnonymousSessionState(sessionId: number) {
  const db = requiredDb(await getDb());
  const row = (await db.select({ noticeAcknowledgedAt: anonymousSessions.noticeAcknowledgedAt, analyticsConsent: anonymousSessions.analyticsConsent, noticeVersion: anonymousSessions.noticeVersion }).from(anonymousSessions).where(eq(anonymousSessions.id, sessionId)).limit(1))[0];
  return row ?? { noticeAcknowledgedAt: null, analyticsConsent: "unknown" as const, noticeVersion: PRIVACY_NOTICE_VERSION };
}

export async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const hash = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${salt}:${hash.toString("hex")}`;
}

export async function verifyPassword(password: string, stored: string) {
  const [salt, original] = stored.split(":");
  if (!salt || !original) return false;
  const calculated = (await scryptAsync(password, salt, 64)) as Buffer;
  const originalBuffer = Buffer.from(original, "hex");
  return originalBuffer.length === calculated.length && timingSafeEqual(originalBuffer, calculated);
}

async function insertId(db: any, table: any, values: any) {
  const result = await db.insert(table).values(values).$returningId();
  return Number(result[0].id);
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = requiredDb(await getDb());
  const values: InsertUser = { openId: user.openId, lastSignedIn: new Date() };
  const updateSet: Record<string, unknown> = { lastSignedIn: new Date() };
  (["name", "email", "loginMethod"] as const).forEach(field => {
    if (user[field] !== undefined) {
      values[field] = user[field];
      updateSet[field] = user[field];
    }
  });
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function getUserById(id: number) {
  const db = requiredDb(await getDb());
  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result[0] ?? null;
}

export async function getUserByEmail(email: string) {
  const db = requiredDb(await getDb());
  const result = await db.select().from(users).where(eq(users.email, normalizeEmail(email))).limit(1);
  return result[0] ?? null;
}

export async function createEmailUser(input: { name: string; email: string; password: string }) {
  const db = requiredDb(await getDb());
  const email = normalizeEmail(input.email);
  const existing = await getUserByEmail(email);
  if (existing) throw new Error("An account already exists for this email.");
  const id = await insertId(db, users, {
    openId: `email:${randomUUID()}`,
    name: toText(input.name, "SignalFoundry member"),
    email,
    passwordHash: await hashPassword(input.password),
    loginMethod: "password",
    role: "user",
    lastSignedIn: new Date(),
  });
  // An owner/admin may invite an email before the recipient creates an account.
  // Claim that pending membership as soon as its matching account exists.
  await db
    .update(workspaceMembers)
    .set({ userId: id })
    .where(and(eq(workspaceMembers.email, email), isNull(workspaceMembers.userId)));
  return (await getUserById(id))!;
}

export async function loginEmailUser(email: string, password: string) {
  const user = await getUserByEmail(email);
  if (!user?.passwordHash || !(await verifyPassword(password, user.passwordHash))) {
    throw new Error("Email or password is incorrect.");
  }
  const db = requiredDb(await getDb());
  await db.update(users).set({ lastSignedIn: new Date() }).where(eq(users.id, user.id));
  await db
    .update(workspaceMembers)
    .set({ userId: user.id })
    .where(and(eq(workspaceMembers.email, normalizeEmail(user.email || "")), isNull(workspaceMembers.userId)));
  return user;
}

export async function createEmailSession(userId: number) {
  const db = requiredDb(await getDb());
  const token = randomBytes(32).toString("base64url");
  const expiresAt = new Date(Date.now() + 1000 * 60 * 60 * 24 * 14);
  await db.insert(userSessions).values({ userId, tokenHash: hashToken(token), expiresAt });
  return { token, expiresAt };
}

export async function getUserFromEmailSession(token?: string) {
  if (!token) return null;
  const db = await getDb();
  if (!db) return null;
  const result = await db
    .select({ user: users })
    .from(userSessions)
    .innerJoin(users, eq(userSessions.userId, users.id))
    .where(and(eq(userSessions.tokenHash, hashToken(token)), gt(userSessions.expiresAt, new Date())))
    .limit(1);
  return result[0]?.user ?? null;
}

export async function destroyEmailSession(token?: string) {
  if (!token) return;
  const db = await getDb();
  if (db) await db.delete(userSessions).where(eq(userSessions.tokenHash, hashToken(token)));
}

export async function requestPasswordReset(email: string) {
  const db = requiredDb(await getDb());
  const user = await getUserByEmail(email);
  if (!user) return { accepted: true };
  const resetToken = randomBytes(24).toString("base64url");
  await db
    .update(users)
    .set({ passwordResetTokenHash: hashToken(resetToken), passwordResetExpiresAt: new Date(Date.now() + 1000 * 60 * 30) })
    .where(eq(users.id, user.id));
  // The token is deliberately not returned. Add an email provider to deliver it in a production rollout.
  return { accepted: true };
}

export async function resetPassword(token: string, password: string) {
  const db = requiredDb(await getDb());
  const found = await db
    .select()
    .from(users)
    .where(and(eq(users.passwordResetTokenHash, hashToken(token)), gt(users.passwordResetExpiresAt, new Date())))
    .limit(1);
  if (!found[0]) throw new Error("This password reset link is invalid or expired.");
  await db
    .update(users)
    .set({ passwordHash: await hashPassword(password), passwordResetTokenHash: null, passwordResetExpiresAt: null })
    .where(eq(users.id, found[0].id));
}

function workspaceSlug(name: string) {
  const base = name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "workspace";
  return `${base}-${randomBytes(3).toString("hex")}`;
}

export async function createWorkspaceForUser(user: User, name: string, seedDemo = false, anonymousSessionId?: number) {
  const db = requiredDb(await getDb());
  if (anonymousSessionId) {
    const existing = await db.select({ id: workspaces.id, plan: workspaces.plan }).from(workspaces).where(eq(workspaces.anonymousSessionId, anonymousSessionId));
    if (existing.some(workspace => workspace.plan === "free") && existing.length >= PLAN_CONFIG.free.maxWorkspaces) {
      throw new Error("The Free plan includes one workspace. Upgrade to Founder to create another.");
    }
  }
  const workspaceId = await insertId(db, workspaces, {
    anonymousSessionId: anonymousSessionId ?? null,
    name: toText(name, "Untitled workspace"),
    slug: workspaceSlug(name),
    plan: "free",
    scoringWeights: JSON.stringify(DEFAULT_WEIGHTS),
  });
  await db.insert(workspaceMembers).values({
    workspaceId,
    userId: user.id,
    displayName: user.name || "Workspace owner",
    email: user.email || `${user.openId}@member.local`,
    role: "owner",
  });
  await db.update(users).set({ currentWorkspaceId: workspaceId }).where(eq(users.id, user.id));
  if (seedDemo) await seedDemoWorkspace(workspaceId, user);
  return workspaceId;
}

export async function ensureWorkspaceForUser(user: User) {
  const db = requiredDb(await getDb());
  if (user.currentWorkspaceId) {
    const membership = await db
      .select()
      .from(workspaceMembers)
      .where(and(eq(workspaceMembers.workspaceId, user.currentWorkspaceId), eq(workspaceMembers.userId, user.id)))
      .limit(1);
    if (membership[0]) return user.currentWorkspaceId;
  }
  const memberships = await db.select().from(workspaceMembers).where(eq(workspaceMembers.userId, user.id)).limit(1);
  if (memberships[0]) {
    await db.update(users).set({ currentWorkspaceId: memberships[0].workspaceId }).where(eq(users.id, user.id));
    return memberships[0].workspaceId;
  }
  return createWorkspaceForUser(user, "Northstar Notes", true);
}

export async function listWorkspacesForUser(userId: number) {
  const db = requiredDb(await getDb());
  const memberships = await db.select().from(workspaceMembers).where(eq(workspaceMembers.userId, userId));
  const result = [] as Array<{ workspace: typeof workspaces.$inferSelect; membership: typeof workspaceMembers.$inferSelect }>;
  for (const membership of memberships) {
    const workspace = await db.select().from(workspaces).where(eq(workspaces.id, membership.workspaceId)).limit(1);
    if (workspace[0]) result.push({ workspace: workspace[0], membership });
  }
  return result;
}

export async function setCurrentWorkspace(userId: number, workspaceId: number) {
  const db = requiredDb(await getDb());
  const membership = await db
    .select()
    .from(workspaceMembers)
    .where(and(eq(workspaceMembers.workspaceId, workspaceId), eq(workspaceMembers.userId, userId)))
    .limit(1);
  if (!membership[0]) throw new Error("You do not have access to this workspace.");
  await db.update(users).set({ currentWorkspaceId: workspaceId }).where(eq(users.id, userId));
}

export async function deleteWorkspaceForUser(user: User, workspaceId: number, confirmationName: string) {
  const { db, membership } = await checkWorkspaceAccess(user.id, workspaceId);
  if (membership.role !== "owner") throw new Error("Only the workspace owner can delete a workspace.");
  const workspace = (await db.select().from(workspaces).where(eq(workspaces.id, workspaceId)).limit(1))[0];
  if (!workspace) throw new Error("Workspace not found.");
  if (confirmationName.trim() !== workspace.name) throw new Error("Type the exact workspace name to confirm deletion.");

  const [workspaceSignals, workspaceProblems] = await Promise.all([
    db.select({ id: signals.id }).from(signals).where(eq(signals.workspaceId, workspaceId)),
    db.select({ id: problems.id }).from(problems).where(eq(problems.workspaceId, workspaceId)),
  ]);
  if (workspaceSignals.length) await db.delete(signalTags).where(inArray(signalTags.signalId, workspaceSignals.map(signal => signal.id)));
  if (workspaceProblems.length) await db.delete(problemSignals).where(inArray(problemSignals.problemId, workspaceProblems.map(problem => problem.id)));
  await Promise.all([
    db.delete(signals).where(eq(signals.workspaceId, workspaceId)),
    db.delete(problems).where(eq(problems.workspaceId, workspaceId)),
    db.delete(opportunities).where(eq(opportunities.workspaceId, workspaceId)),
    db.delete(experiments).where(eq(experiments.workspaceId, workspaceId)),
    db.delete(decisions).where(eq(decisions.workspaceId, workspaceId)),
    db.delete(customers).where(eq(customers.workspaceId, workspaceId)),
    db.delete(customerSegments).where(eq(customerSegments.workspaceId, workspaceId)),
    db.delete(tags).where(eq(tags.workspaceId, workspaceId)),
    db.delete(notes).where(eq(notes.workspaceId, workspaceId)),
    db.delete(savedViews).where(eq(savedViews.workspaceId, workspaceId)),
    db.delete(subscriptions).where(eq(subscriptions.workspaceId, workspaceId)),
    db.delete(workspaceMembers).where(eq(workspaceMembers.workspaceId, workspaceId)),
  ]);
  await db.update(users).set({ currentWorkspaceId: null }).where(eq(users.currentWorkspaceId, workspaceId));
  await db.delete(workspaces).where(eq(workspaces.id, workspaceId));
  return { success: true } as const;
}

export async function resetAnonymousWorkspace(user: User, sessionId: number, confirmation: string) {
  if (confirmation.trim() !== "RESET WORKSPACE") throw new Error("Type RESET WORKSPACE to confirm.");
  const db = requiredDb(await getDb());
  const owned = await db.select({ id: workspaces.id }).from(workspaces).where(eq(workspaces.anonymousSessionId, sessionId));
  for (const workspace of owned) await deleteWorkspaceForUser(user, workspace.id, (await db.select({ name: workspaces.name }).from(workspaces).where(eq(workspaces.id, workspace.id)).limit(1))[0]?.name || "");
  await db.update(users).set({ currentWorkspaceId: null }).where(eq(users.id, user.id));
  const workspaceId = await createWorkspaceForUser(user, "Northstar Notes", true, sessionId);
  return { success: true, workspaceId } as const;
}

async function checkWorkspaceAccess(userId: number, workspaceId: number) {
  const db = requiredDb(await getDb());
  const membership = await db
    .select()
    .from(workspaceMembers)
    .where(and(eq(workspaceMembers.workspaceId, workspaceId), eq(workspaceMembers.userId, userId)))
    .limit(1);
  if (!membership[0]) throw new Error("You do not have access to this workspace.");
  return { db, membership: membership[0] };
}

export async function getWorkspaceState(user: User, requestedWorkspaceId?: number) {
  const workspaceId = requestedWorkspaceId || (await ensureWorkspaceForUser(user));
  const { db, membership } = await checkWorkspaceAccess(user.id, workspaceId);
  const workspace = (await db.select().from(workspaces).where(eq(workspaces.id, workspaceId)).limit(1))[0];
  if (!workspace) throw new Error("Workspace not found.");
  const [allWorkspaces, members, allSegments, allCustomers, allTags, allSignals, allProblems, allOpportunities, allExperiments, allDecisions, allNotes, allViews] = await Promise.all([
    listWorkspacesForUser(user.id),
    db.select().from(workspaceMembers).where(eq(workspaceMembers.workspaceId, workspaceId)),
    db.select().from(customerSegments).where(eq(customerSegments.workspaceId, workspaceId)),
    db.select().from(customers).where(eq(customers.workspaceId, workspaceId)),
    db.select().from(tags).where(eq(tags.workspaceId, workspaceId)),
    db.select().from(signals).where(eq(signals.workspaceId, workspaceId)).orderBy(desc(signals.createdAt)),
    db.select().from(problems).where(eq(problems.workspaceId, workspaceId)).orderBy(desc(problems.updatedAt)),
    db.select().from(opportunities).where(eq(opportunities.workspaceId, workspaceId)).orderBy(desc(opportunities.updatedAt)),
    db.select().from(experiments).where(eq(experiments.workspaceId, workspaceId)).orderBy(desc(experiments.createdAt)),
    db.select().from(decisions).where(eq(decisions.workspaceId, workspaceId)).orderBy(desc(decisions.createdAt)),
    db.select().from(notes).where(eq(notes.workspaceId, workspaceId)).orderBy(desc(notes.createdAt)),
    db.select().from(savedViews).where(eq(savedViews.workspaceId, workspaceId)),
  ]);
  const [allProblemSignals, allSignalTags] = await Promise.all([
    allProblems.length ? db.select().from(problemSignals).where(inArray(problemSignals.problemId, allProblems.map(problem => problem.id))) : [],
    allSignals.length ? db.select().from(signalTags).where(inArray(signalTags.signalId, allSignals.map(signal => signal.id))) : [],
  ]);
  return {
    workspace,
    membership,
    workspaces: allWorkspaces,
    members,
    segments: allSegments,
    customers: allCustomers,
    tags: allTags,
    signals: allSignals,
    signalTags: allSignalTags,
    problems: allProblems,
    problemSignals: allProblemSignals,
    opportunities: allOpportunities,
    experiments: allExperiments,
    decisions: allDecisions,
    notes: allNotes,
    savedViews: allViews,
  };
}

export async function updateWorkspaceSettings(user: User, workspaceId: number, input: { name?: string; scoringWeights?: Record<string, number> }) {
  const { db, membership } = await checkWorkspaceAccess(user.id, workspaceId);
  if (membership.role === "member") throw new Error("Only owners and admins can change workspace settings.");
  const update: Record<string, unknown> = {};
  if (input.name) update.name = input.name.trim();
  if (input.scoringWeights) update.scoringWeights = JSON.stringify(input.scoringWeights);
  if (Object.keys(update).length) await db.update(workspaces).set(update as any).where(eq(workspaces.id, workspaceId));
  return (await db.select().from(workspaces).where(eq(workspaces.id, workspaceId)).limit(1))[0];
}

export async function mutateEntity(user: User, workspaceId: number, entity: EntityName, action: "create" | "update" | "delete", payload: Record<string, unknown>) {
  const { db, membership } = await checkWorkspaceAccess(user.id, workspaceId);
  const evidenceEntities: EntityName[] = ["signal", "note"];
  if (membership.role === "member" && !(action === "create" && evidenceEntities.includes(entity))) {
    throw new Error("Members can add signals and notes, but only owners and admins can change workspace records.");
  }
  if (entity === "member" && membership.role !== "owner") {
    throw new Error("Only the workspace owner can manage team roles.");
  }
  const id = toInt(payload.id);
  const assertTitle = () => {
    const title = toText(payload.title || payload.name);
    if (!title) throw new Error("A title or name is required.");
    return title;
  };
  const deleteWhere = async (table: any) => {
    if (!id) throw new Error("Record id is required.");
    await db.delete(table).where(and(eq(table.id, id), eq(table.workspaceId, workspaceId)));
  };
  const requireWorkspaceRelation = async (table: any, rawId: unknown, label: string) => {
    const relationId = toInt(rawId);
    if (!relationId) return null;
    const relation = await db.select({ id: table.id }).from(table).where(and(eq(table.id, relationId), eq(table.workspaceId, workspaceId))).limit(1);
    if (!relation[0]) throw new Error(`The selected ${label} is not available in this workspace.`);
    return relationId;
  };
  const replaceProblemEvidence = async (problemId: number) => {
    if (!Array.isArray(payload.signalIds)) return;
    const signalIds = [...new Set(payload.signalIds.map(value => toInt(value)).filter(Boolean))];
    for (const signalId of signalIds) await requireWorkspaceRelation(signals, signalId, "signal");
    await db.delete(problemSignals).where(eq(problemSignals.problemId, problemId));
    if (signalIds.length) await db.insert(problemSignals).values(signalIds.map(signalId => ({ problemId, signalId })));
  };

  if (action === "delete") {
    const map: Record<EntityName, any> = { signal: signals, problem: problems, opportunity: opportunities, experiment: experiments, decision: decisions, segment: customerSegments, customer: customers, tag: tags, note: notes, member: workspaceMembers, savedView: savedViews };
    await deleteWhere(map[entity]);
    return { success: true };
  }

  if (entity === "signal") {
    const values = {
      title: assertTitle(), detail: toText(payload.detail), source: toText(payload.source, "interview"), urgency: toText(payload.urgency, "medium"), status: toText(payload.status, "new"), productArea: toText(payload.productArea, "Core product"), evidenceStrength: score(payload.evidenceStrength), customerId: await requireWorkspaceRelation(customers, payload.customerId, "customer"), segmentId: await requireWorkspaceRelation(customerSegments, payload.segmentId, "segment"),
    };
    if (action === "create") await db.insert(signals).values({ workspaceId, ...values } as any);
    else await db.update(signals).set(values as any).where(and(eq(signals.id, id), eq(signals.workspaceId, workspaceId)));
  }
  if (entity === "problem") {
    const values = { title: assertTitle(), summary: toText(payload.summary), status: toText(payload.status, "emerging"), frequency: score(payload.frequency), severity: score(payload.severity), owner: toText(payload.owner) || null };
    if (action === "create") {
      const problemId = await insertId(db, problems, { workspaceId, ...values } as any);
      await replaceProblemEvidence(problemId);
    } else {
      await db.update(problems).set(values as any).where(and(eq(problems.id, id), eq(problems.workspaceId, workspaceId)));
      await replaceProblemEvidence(id);
    }
  }
  if (entity === "opportunity") {
    const values = { title: assertTitle(), description: toText(payload.description), segment: toText(payload.segment) || null, problemId: await requireWorkspaceRelation(problems, payload.problemId, "problem"), frequency: score(payload.frequency), severity: score(payload.severity), willingnessToPay: score(payload.willingnessToPay), strategicFit: score(payload.strategicFit), effort: score(payload.effort), status: toText(payload.status, "backlog") };
    if (action === "create") await db.insert(opportunities).values({ workspaceId, ...values } as any);
    else await db.update(opportunities).set(values as any).where(and(eq(opportunities.id, id), eq(opportunities.workspaceId, workspaceId)));
  }
  if (entity === "experiment") {
    const values = { title: assertTitle(), hypothesis: toText(payload.hypothesis), method: toText(payload.method, "Interview"), successMetric: toText(payload.successMetric), result: toText(payload.result) || null, status: toText(payload.status, "planned"), opportunityId: await requireWorkspaceRelation(opportunities, payload.opportunityId, "opportunity") };
    if (!values.hypothesis || !values.successMetric) throw new Error("Hypothesis and success metric are required.");
    if (action === "create") await db.insert(experiments).values({ workspaceId, ...values } as any);
    else await db.update(experiments).set(values as any).where(and(eq(experiments.id, id), eq(experiments.workspaceId, workspaceId)));
  }
  if (entity === "decision") {
    const values = { title: assertTitle(), outcome: toText(payload.outcome, "investigate"), reasoning: toText(payload.reasoning), evidence: toText(payload.evidence) || null, decidedBy: toText(payload.decidedBy, user.name || "Workspace member"), opportunityId: await requireWorkspaceRelation(opportunities, payload.opportunityId, "opportunity") };
    if (!values.reasoning) throw new Error("Decision reasoning is required.");
    if (action === "create") await db.insert(decisions).values({ workspaceId, ...values } as any);
    else await db.update(decisions).set(values as any).where(and(eq(decisions.id, id), eq(decisions.workspaceId, workspaceId)));
  }
  if (entity === "segment") {
    const values = { name: assertTitle(), description: toText(payload.description) || null, color: toText(payload.color, "#4F46E5"), audienceSize: Math.max(0, toInt(payload.audienceSize)) };
    if (action === "create") await db.insert(customerSegments).values({ workspaceId, ...values });
    else await db.update(customerSegments).set(values).where(and(eq(customerSegments.id, id), eq(customerSegments.workspaceId, workspaceId)));
  }
  if (entity === "customer") {
    const values = { name: assertTitle(), email: toText(payload.email) || null, company: toText(payload.company) || null, title: toText(payload.title) || null, status: toText(payload.status, "active"), lifetimeValue: Math.max(0, toInt(payload.lifetimeValue)), notes: toText(payload.notes) || null, segmentId: await requireWorkspaceRelation(customerSegments, payload.segmentId, "segment") };
    if (action === "create") await db.insert(customers).values({ workspaceId, ...values } as any);
    else await db.update(customers).set(values as any).where(and(eq(customers.id, id), eq(customers.workspaceId, workspaceId)));
  }
  if (entity === "tag") {
    const values = { name: assertTitle(), color: toText(payload.color, "#818CF8") };
    if (action === "create") await db.insert(tags).values({ workspaceId, ...values });
    else await db.update(tags).set(values).where(and(eq(tags.id, id), eq(tags.workspaceId, workspaceId)));
  }
  if (entity === "note") {
    const values = { entityType: toText(payload.entityType, "workspace"), entityId: toInt(payload.entityId) || null, body: toText(payload.body), createdBy: user.name || "Workspace member" };
    if (!values.body) throw new Error("Note body is required.");
    if (action === "create") await db.insert(notes).values({ workspaceId, ...values });
    else await db.update(notes).set(values).where(and(eq(notes.id, id), eq(notes.workspaceId, workspaceId)));
  }
  if (entity === "member") {
    const role = toText(payload.role, "member");
    if (!["admin", "member"].includes(role)) throw new Error("Only one workspace owner is supported in this MVP.");
    const values = { displayName: assertTitle(), email: normalizeEmail(toText(payload.email)), role };
    if (!values.email) throw new Error("Member email is required.");
    if (action === "create") {
      const existingUser = await getUserByEmail(values.email);
      await db.insert(workspaceMembers).values({ workspaceId, userId: existingUser?.id ?? null, ...values } as any);
    } else {
      const existingMembership = await db.select().from(workspaceMembers).where(and(eq(workspaceMembers.id, id), eq(workspaceMembers.workspaceId, workspaceId))).limit(1);
      if (!existingMembership[0] || existingMembership[0].role === "owner") throw new Error("The workspace owner role cannot be reassigned or removed.");
      const existingUser = await getUserByEmail(values.email);
      await db.update(workspaceMembers).set({ ...values, userId: existingUser?.id ?? null } as any).where(and(eq(workspaceMembers.id, id), eq(workspaceMembers.workspaceId, workspaceId)));
    }
  }
  if (entity === "savedView") {
    const values = { name: assertTitle(), entityType: toText(payload.entityType, "signal"), filterJson: toText(payload.filterJson, "{}") };
    if (action === "create") await db.insert(savedViews).values({ workspaceId, ...values });
    else await db.update(savedViews).set(values).where(and(eq(savedViews.id, id), eq(savedViews.workspaceId, workspaceId)));
  }
  return { success: true };
}

export async function importSignals(user: User, workspaceId: number, rows: Array<Record<string, unknown>>) {
  const { db } = await checkWorkspaceAccess(user.id, workspaceId);
  const cleaned = rows.slice(0, 100).map(row => ({
    workspaceId,
    title: toText(row.title || row.subject, "Imported signal"),
    detail: toText(row.detail || row.notes),
    source: toText(row.source, "other"),
    urgency: toText(row.urgency, "medium"),
    status: "new",
    productArea: toText(row.productArea || row.product_area, "Imported"),
    evidenceStrength: score(row.evidenceStrength || row.evidence_strength),
  }));
  if (!cleaned.length) throw new Error("No importable rows were found.");
  await db.insert(signals).values(cleaned as any);
  return { imported: cleaned.length };
}

export async function chooseTestPlan(user: User, workspaceId: number, plan: "free" | "founder" | "team") {
  const { db, membership } = await checkWorkspaceAccess(user.id, workspaceId);
  if (membership.role !== "owner") throw new Error("Only the workspace owner can change the plan.");
  if (plan === "team") throw new Error("Team is planned and not purchasable in Phase 1.");
  if (plan === "founder" && stripeTestConfiguration().looksLive) throw new Error("Live Stripe configuration is disabled in this MVP.");
  if (plan === "founder" && !stripeTestConfiguration().enabled) throw new Error("Founder checkout is unavailable until Stripe test credentials are configured.");
  await db.update(workspaces).set({ plan }).where(eq(workspaces.id, workspaceId));
  await db.insert(subscriptions).values({ workspaceId, plan, status: "test_active", paymentProvider: "test_checkout" });
  return { success: true, plan };
}

async function seedDemoWorkspace(workspaceId: number, user: User) {
  const db = requiredDb(await getDb());
  const [soloId, agencyId, teamId] = await Promise.all([
    insertId(db, customerSegments, { workspaceId, name: "Solo operators", description: "Founder-led SaaS businesses with a lean stack.", color: "#4F46E5", audienceSize: 1260 }),
    insertId(db, customerSegments, { workspaceId, name: "Small agencies", description: "Client-service teams validating productized offers.", color: "#0F766E", audienceSize: 480 }),
    insertId(db, customerSegments, { workspaceId, name: "Product teams", description: "Early-stage teams building repeatable discovery rituals.", color: "#B45309", audienceSize: 730 }),
  ]);
  const tagIds = await Promise.all([
    insertId(db, tags, { workspaceId, name: "activation", color: "#4F46E5" }),
    insertId(db, tags, { workspaceId, name: "pricing", color: "#E11D48" }),
    insertId(db, tags, { workspaceId, name: "workflow", color: "#0F766E" }),
    insertId(db, tags, { workspaceId, name: "evidence", color: "#B45309" }),
  ]);
  const customerRows = [
    { name: "Maya Chen", email: "maya@dovetaillabs.test", company: "Dovetail Labs", title: "Founder", status: "active", lifetimeValue: 1200, segmentId: soloId, notes: "Weekly customer calls; uses Notion for research." },
    { name: "Jon Bell", email: "jon@metronome.test", company: "Metronome Studio", title: "Principal", status: "active", lifetimeValue: 6400, segmentId: agencyId, notes: "Runs discovery for four client accounts." },
    { name: "Sofia Reyes", email: "sofia@clover.test", company: "Clover CRM", title: "Product Lead", status: "prospect", lifetimeValue: 0, segmentId: teamId, notes: "Needs a consistent evidence trail for roadmap reviews." },
    { name: "Theo Park", email: "theo@highland.test", company: "Highland Hosting", title: "Founder", status: "active", lifetimeValue: 900, segmentId: soloId, notes: "Support inbox is the current source of truth." },
    { name: "Amira Haddad", email: "amira@weave.test", company: "Weave & Co", title: "Strategy Director", status: "prospect", lifetimeValue: 0, segmentId: agencyId, notes: "Shares research summaries with clients every fortnight." },
  ];
  const customerIds: number[] = [];
  for (const row of customerRows) customerIds.push(await insertId(db, customers, { workspaceId, ...row } as any));
  const signalRows = [
    { title: "I can see the quotes, but not the pattern across calls", detail: "Maya tags interview notes in Notion but cannot tell when an issue appears in multiple segments.", source: "interview", urgency: "high", status: "reviewing", productArea: "Research synthesis", evidenceStrength: 5, customerId: customerIds[0], segmentId: soloId },
    { title: "Client evidence gets lost between discovery and the roadmap", detail: "Jon exports notes to a slide deck, then teams rebuild the rationale in Jira.", source: "interview", urgency: "high", status: "linked", productArea: "Evidence handoff", evidenceStrength: 5, customerId: customerIds[1], segmentId: agencyId },
    { title: "Need a faster way to decide whether a request is a one-off", detail: "Sofia wants product reviews to include frequency and severity, not just a loud quote.", source: "feature_request", urgency: "critical", status: "linked", productArea: "Prioritisation", evidenceStrength: 5, customerId: customerIds[2], segmentId: teamId },
    { title: "Support themes are invisible until they become a fire", detail: "Theo’s support requests sit in Help Scout and get reviewed only when churn is imminent.", source: "support", urgency: "high", status: "new", productArea: "Signal inbox", evidenceStrength: 4, customerId: customerIds[3], segmentId: soloId },
    { title: "A shareable client-ready decision log would save us hours", detail: "Amira currently maintains a manual decision ledger in a client deck.", source: "interview", urgency: "medium", status: "reviewing", productArea: "Decision log", evidenceStrength: 4, customerId: customerIds[4], segmentId: agencyId },
    { title: "I’d pay for a simple scoring framework my team can trust", detail: "Teams want to tune criteria rather than accept a black-box priority score.", source: "sales", urgency: "high", status: "linked", productArea: "Prioritisation", evidenceStrength: 5, customerId: customerIds[2], segmentId: teamId },
    { title: "Feature requests lack the original customer context", detail: "A support ticket title gets copied into the roadmap without segment or customer context.", source: "support", urgency: "medium", status: "new", productArea: "Evidence handoff", evidenceStrength: 3, customerId: customerIds[3], segmentId: soloId },
    { title: "We need one workspace per client, not a giant research folder", detail: "Agency portfolios blur together when research sits in a shared tool.", source: "feature_request", urgency: "medium", status: "linked", productArea: "Workspace", evidenceStrength: 4, customerId: customerIds[1], segmentId: agencyId },
  ];
  const signalIds: number[] = [];
  for (const row of signalRows) signalIds.push(await insertId(db, signals, { workspaceId, ...row } as any));
  await db.insert(signalTags).values([{ signalId: signalIds[0], tagId: tagIds[3] }, { signalId: signalIds[1], tagId: tagIds[0] }, { signalId: signalIds[2], tagId: tagIds[1] }, { signalId: signalIds[5], tagId: tagIds[1] }]);
  const problemPattern = await insertId(db, problems, { workspaceId, title: "Founders cannot see recurring patterns across scattered feedback", summary: "Customer evidence is held in tools built for individual notes, not cross-customer pattern recognition.", status: "validated", frequency: 5, severity: 5, owner: user.name || "You" });
  const problemHandoff = await insertId(db, problems, { workspaceId, title: "Evidence disappears during roadmap handoff", summary: "Teams lose the customer quote, segment, and decision rationale as requests move into product planning.", status: "validated", frequency: 4, severity: 4, owner: user.name || "You" });
  const problemReview = await insertId(db, problems, { workspaceId, title: "Prioritisation conversations rely on intuition instead of transparent criteria", summary: "Small teams need an editable shared score to make trade-offs visible.", status: "emerging", frequency: 4, severity: 5, owner: user.name || "You" });
  await db.insert(problemSignals).values([{ problemId: problemPattern, signalId: signalIds[0] }, { problemId: problemPattern, signalId: signalIds[3] }, { problemId: problemHandoff, signalId: signalIds[1] }, { problemId: problemHandoff, signalId: signalIds[6] }, { problemId: problemReview, signalId: signalIds[2] }, { problemId: problemReview, signalId: signalIds[5] }]);
  const opportunityIds = await Promise.all([
    insertId(db, opportunities, { workspaceId, problemId: problemPattern, title: "Pattern board with linked evidence", description: "Cluster signals by customer problem and expose the evidence behind each cluster.", segment: "Solo operators", frequency: 5, severity: 5, willingnessToPay: 4, strategicFit: 5, effort: 3, status: "planned" }),
    insertId(db, opportunities, { workspaceId, problemId: problemReview, title: "Transparent opportunity scorecard", description: "Tune the scoring criteria and compare the next bets without hiding the math.", segment: "Product teams", frequency: 4, severity: 5, willingnessToPay: 4, strategicFit: 5, effort: 2, status: "testing" }),
    insertId(db, opportunities, { workspaceId, problemId: problemHandoff, title: "Decision log with evidence export", description: "Record what was decided, why, and which customer evidence supports it.", segment: "Small agencies", frequency: 4, severity: 4, willingnessToPay: 4, strategicFit: 4, effort: 3, status: "considering" }),
    insertId(db, opportunities, { workspaceId, problemId: problemHandoff, title: "One-click research to Jira brief", description: "Export an opportunity with linked customer context into an implementation brief.", segment: "Small agencies", frequency: 3, severity: 3, willingnessToPay: 3, strategicFit: 3, effort: 5, status: "backlog" }),
  ]);
  await db.insert(experiments).values([
    { workspaceId, opportunityId: opportunityIds[1], title: "Scorecard prototype review", hypothesis: "If teams can see and edit the score calculation, they will use it in weekly roadmap reviews.", method: "5 moderated prototype sessions", successMetric: "4/5 participants independently explain and change the prioritisation result.", result: "4 of 5 participants trusted the model after changing effort weight.", status: "complete" },
    { workspaceId, opportunityId: opportunityIds[0], title: "Pattern board concierge test", hypothesis: "Founders will bring 10+ signals into one place if clustering recurring issues is faster than reviewing notes manually.", method: "Concierge synthesis with 3 founders", successMetric: "Each participant identifies at least one previously unseen recurring problem.", result: null, status: "running" },
    { workspaceId, opportunityId: opportunityIds[2], title: "Decision export smoke test", hypothesis: "Agencies will share a decision log when it is client-ready and evidence-backed.", method: "Clickable prototype", successMetric: "3/4 agency leads request a live pilot.", result: null, status: "planned" },
  ]);
  await db.insert(decisions).values([
    { workspaceId, opportunityId: opportunityIds[1], title: "Test the scorecard before automation", outcome: "test", reasoning: "The clearest willingness-to-pay signal is for transparent prioritisation. Test that behavior before adding integrations.", evidence: "5 interview/sales signals, scorecard prototype review", decidedBy: user.name || "You" },
    { workspaceId, opportunityId: opportunityIds[0], title: "Build evidence linking into the core workflow", outcome: "build", reasoning: "Repeated feedback shows that preserving the trail from signal to problem is table stakes for trusted decisions.", evidence: "Signals SF-001, SF-004 and SF-007", decidedBy: user.name || "You" },
    { workspaceId, opportunityId: opportunityIds[3], title: "Defer Jira export", outcome: "defer", reasoning: "Integration demand is credible but less urgent than establishing a clean internal evidence model.", evidence: "One agency request; high estimated effort", decidedBy: user.name || "You" },
  ]);
  await db.insert(notes).values([
    { workspaceId, entityType: "workspace", entityId: null, body: "Demo workspace uses fictional founders, agencies, and teams. Nothing here represents real customer data.", createdBy: "SignalFoundry" },
    { workspaceId, entityType: "opportunity", entityId: opportunityIds[1], body: "The score formula should remain visible on both the table and matrix views.", createdBy: user.name || "You" },
  ]);
  await db.insert(savedViews).values([
    { workspaceId, name: "High urgency signals", entityType: "signal", filterJson: JSON.stringify({ urgency: "high" }) },
    { workspaceId, name: "Prioritise next", entityType: "opportunity", filterJson: JSON.stringify({ status: ["testing", "considering"] }) },
  ]);
}
