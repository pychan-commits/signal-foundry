import { createHmac, randomUUID } from "node:crypto";
import { z } from "zod";
import { getDb } from "./db";
import { signalAttachments, signals } from "../drizzle/schema";
import { and, eq } from "drizzle-orm";

export const imageKitUploadSchema = z.object({
  workspaceId: z.number().int().positive(),
  signalId: z.number().int().positive(),
  fileName: z.string().trim().min(1).max(240),
  mimeType: z.enum(["image/png", "image/jpeg", "image/webp", "application/pdf"]),
  fileSize: z.number().int().positive().max(10 * 1024 * 1024),
});

export function imageKitStatus() {
  const configured = Boolean(process.env.IMAGEKIT_PRIVATE_KEY && process.env.IMAGEKIT_PUBLIC_KEY && process.env.IMAGEKIT_URL_ENDPOINT);
  return { configured, maxFileSize: 10 * 1024 * 1024, allowedMimeTypes: imageKitUploadSchema.shape.mimeType.options };
}

export async function createImageKitUploadAuth(input: z.infer<typeof imageKitUploadSchema>, userId: number) {
  if (!imageKitStatus().configured) throw new Error("ImageKit attachments are not configured for this workspace.");
  const db = await getDb();
  if (!db) throw new Error("Database unavailable.");
  const signal = (await db.select({ id: signals.id }).from(signals).where(and(eq(signals.id, input.signalId), eq(signals.workspaceId, input.workspaceId))).limit(1))[0];
  if (!signal) throw new Error("The signal is not available in this workspace.");
  void userId;
  const expire = Math.floor(Date.now() / 1000) + 10 * 60;
  const token = randomUUID();
  const signature = createHmac("sha1", process.env.IMAGEKIT_PRIVATE_KEY!).update(token + expire).digest("hex");
  return {
    token,
    expire,
    signature,
    publicKey: process.env.IMAGEKIT_PUBLIC_KEY,
    urlEndpoint: process.env.IMAGEKIT_URL_ENDPOINT,
    fileName: input.fileName,
    folder: `/signalfoundry/${input.workspaceId}/${input.signalId}`,
    useUniqueFileName: true,
    maxFileSize: imageKitStatus().maxFileSize,
    allowedMimeTypes: imageKitStatus().allowedMimeTypes,
  };
}

export async function recordImageKitAttachment(input: { workspaceId: number; signalId: number; providerFileId: string; fileName: string; url: string; mimeType: string; fileSize: number }) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable.");
  const parsed = imageKitUploadSchema.parse({ ...input, fileName: input.fileName, mimeType: input.mimeType, fileSize: input.fileSize });
  const signal = (await db.select({ id: signals.id }).from(signals).where(and(eq(signals.id, parsed.signalId), eq(signals.workspaceId, parsed.workspaceId))).limit(1))[0];
  if (!signal) throw new Error("The signal is not available in this workspace.");
  await db.insert(signalAttachments).values({ ...parsed, providerFileId: input.providerFileId, url: input.url });
  return { success: true } as const;
}
