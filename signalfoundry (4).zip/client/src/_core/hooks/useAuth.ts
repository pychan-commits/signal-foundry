import { trpc } from "@/lib/trpc";

export function useAuth() {
  const session = trpc.session.info.useQuery(undefined, { retry: false, refetchOnWindowFocus: false });
  return {
    user: null,
    loading: session.isLoading,
    error: session.error ?? null,
    isAuthenticated: false,
    isAnonymous: Boolean(session.data?.ready),
    refresh: () => session.refetch(),
    logout: async () => undefined,
  };
}
