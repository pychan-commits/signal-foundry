import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const anonymousSessions = mysqlTable("anonymous_sessions", {
  id: int("id").autoincrement().primaryKey(),
  publicId: varchar("publicId", { length: 64 }).notNull().unique(),
  tokenHash: varchar("tokenHash", { length: 128 }).notNull().unique(),
  noticeVersion: varchar("noticeVersion", { length: 32 }).notNull().default("2026-10-v1"),
  noticeAcknowledgedAt: timestamp("noticeAcknowledgedAt"),
  analyticsConsent: mysqlEnum("analyticsConsent", ["unknown", "granted", "withdrawn"]).default("unknown").notNull(),
  analyticsConsentAt: timestamp("analyticsConsentAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  lastSeenAt: timestamp("lastSeenAt").defaultNow().notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
});

/** User identities support both starter OAuth users and explicit email/password accounts. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 96 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }).unique(),
  passwordHash: varchar("passwordHash", { length: 255 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  currentWorkspaceId: int("currentWorkspaceId"),
  passwordResetTokenHash: varchar("passwordResetTokenHash", { length: 128 }),
  passwordResetExpiresAt: timestamp("passwordResetExpiresAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const userSessions = mysqlTable("user_sessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  tokenHash: varchar("tokenHash", { length: 128 }).notNull().unique(),
  expiresAt: timestamp("expiresAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const workspaces = mysqlTable("workspaces", {
  id: int("id").autoincrement().primaryKey(),
  anonymousSessionId: int("anonymousSessionId"),
  name: varchar("name", { length: 140 }).notNull(),
  slug: varchar("slug", { length: 160 }).notNull().unique(),
  plan: mysqlEnum("plan", ["free", "founder", "team"]).default("free").notNull(),
  scoringWeights: text("scoringWeights").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const workspaceMembers = mysqlTable("workspace_members", {
  id: int("id").autoincrement().primaryKey(),
  workspaceId: int("workspaceId").notNull(),
  userId: int("userId"),
  displayName: varchar("displayName", { length: 160 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  role: mysqlEnum("role", ["owner", "admin", "member"]).default("member").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const customerSegments = mysqlTable("customer_segments", {
  id: int("id").autoincrement().primaryKey(),
  workspaceId: int("workspaceId").notNull(),
  name: varchar("name", { length: 140 }).notNull(),
  description: text("description"),
  color: varchar("color", { length: 16 }).default("#4F46E5").notNull(),
  audienceSize: int("audienceSize").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const customers = mysqlTable("customers", {
  id: int("id").autoincrement().primaryKey(),
  workspaceId: int("workspaceId").notNull(),
  segmentId: int("segmentId"),
  name: varchar("name", { length: 160 }).notNull(),
  email: varchar("email", { length: 320 }),
  company: varchar("company", { length: 160 }),
  title: varchar("title", { length: 160 }),
  status: mysqlEnum("status", ["active", "prospect", "inactive"]).default("active").notNull(),
  lifetimeValue: int("lifetimeValue").default(0).notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const tags = mysqlTable("tags", {
  id: int("id").autoincrement().primaryKey(),
  workspaceId: int("workspaceId").notNull(),
  name: varchar("name", { length: 80 }).notNull(),
  color: varchar("color", { length: 16 }).default("#818CF8").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const signals = mysqlTable("signals", {
  id: int("id").autoincrement().primaryKey(),
  workspaceId: int("workspaceId").notNull(),
  customerId: int("customerId"),
  segmentId: int("segmentId"),
  title: varchar("title", { length: 240 }).notNull(),
  detail: text("detail"),
  source: mysqlEnum("source", ["interview", "support", "sales", "feature_request", "survey", "other"]).default("interview").notNull(),
  urgency: mysqlEnum("urgency", ["low", "medium", "high", "critical"]).default("medium").notNull(),
  status: mysqlEnum("status", ["new", "reviewing", "linked", "archived"]).default("new").notNull(),
  productArea: varchar("productArea", { length: 120 }).default("Core product").notNull(),
  evidenceStrength: int("evidenceStrength").default(3).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const signalTags = mysqlTable("signal_tags", {
  id: int("id").autoincrement().primaryKey(),
  signalId: int("signalId").notNull(),
  tagId: int("tagId").notNull(),
});
export const signalAttachments = mysqlTable("signal_attachments", {
  id: int("id").autoincrement().primaryKey(),
  workspaceId: int("workspaceId").notNull(),
  signalId: int("signalId").notNull(),
  providerFileId: varchar("providerFileId", { length: 240 }).notNull(),
  fileName: varchar("fileName", { length: 240 }).notNull(),
  url: text("url").notNull(),
  mimeType: varchar("mimeType", { length: 120 }).notNull(),
  fileSize: int("fileSize").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export const problems = mysqlTable("problems", {
  id: int("id").autoincrement().primaryKey(),
  workspaceId: int("workspaceId").notNull(),
  title: varchar("title", { length: 240 }).notNull(),
  summary: text("summary"),
  status: mysqlEnum("status", ["emerging", "validated", "watching", "resolved"]).default("emerging").notNull(),
  frequency: int("frequency").default(3).notNull(),
  severity: int("severity").default(3).notNull(),
  owner: varchar("owner", { length: 160 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const problemSignals = mysqlTable("problem_signals", {
  id: int("id").autoincrement().primaryKey(),
  problemId: int("problemId").notNull(),
  signalId: int("signalId").notNull(),
});

export const opportunities = mysqlTable("opportunities", {
  id: int("id").autoincrement().primaryKey(),
  workspaceId: int("workspaceId").notNull(),
  problemId: int("problemId"),
  title: varchar("title", { length: 240 }).notNull(),
  description: text("description"),
  segment: varchar("segment", { length: 160 }),
  frequency: int("frequency").default(3).notNull(),
  severity: int("severity").default(3).notNull(),
  willingnessToPay: int("willingnessToPay").default(3).notNull(),
  strategicFit: int("strategicFit").default(3).notNull(),
  effort: int("effort").default(3).notNull(),
  status: mysqlEnum("status", ["backlog", "considering", "testing", "planned", "shipped"]).default("backlog").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const experiments = mysqlTable("experiments", {
  id: int("id").autoincrement().primaryKey(),
  workspaceId: int("workspaceId").notNull(),
  opportunityId: int("opportunityId"),
  title: varchar("title", { length: 240 }).notNull(),
  hypothesis: text("hypothesis").notNull(),
  method: varchar("method", { length: 160 }).notNull(),
  successMetric: text("successMetric").notNull(),
  result: text("result"),
  status: mysqlEnum("status", ["planned", "running", "complete", "inconclusive"]).default("planned").notNull(),
  dueDate: timestamp("dueDate"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const decisions = mysqlTable("decisions", {
  id: int("id").autoincrement().primaryKey(),
  workspaceId: int("workspaceId").notNull(),
  opportunityId: int("opportunityId"),
  title: varchar("title", { length: 240 }).notNull(),
  outcome: mysqlEnum("outcome", ["build", "test", "investigate", "defer", "decline"]).notNull(),
  reasoning: text("reasoning").notNull(),
  evidence: text("evidence"),
  decidedBy: varchar("decidedBy", { length: 160 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const notes = mysqlTable("notes", {
  id: int("id").autoincrement().primaryKey(),
  workspaceId: int("workspaceId").notNull(),
  entityType: varchar("entityType", { length: 80 }).notNull(),
  entityId: int("entityId"),
  body: text("body").notNull(),
  createdBy: varchar("createdBy", { length: 160 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const savedViews = mysqlTable("saved_views", {
  id: int("id").autoincrement().primaryKey(),
  workspaceId: int("workspaceId").notNull(),
  name: varchar("name", { length: 140 }).notNull(),
  entityType: varchar("entityType", { length: 80 }).notNull(),
  filterJson: text("filterJson").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const subscriptions = mysqlTable("subscriptions", {
  id: int("id").autoincrement().primaryKey(),
  workspaceId: int("workspaceId").notNull(),
  plan: mysqlEnum("plan", ["free", "founder", "team"]).notNull(),
  status: mysqlEnum("status", ["test_active", "cancelled"]).default("test_active").notNull(),
  paymentProvider: varchar("paymentProvider", { length: 64 }).default("test_checkout").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export const billingEntitlements = mysqlTable("billing_entitlements", {
  id: int("id").autoincrement().primaryKey(),
  workspaceId: int("workspaceId").notNull(),
  stripeCustomerId: varchar("stripeCustomerId", { length: 240 }),
  stripeSubscriptionId: varchar("stripeSubscriptionId", { length: 240 }),
  plan: mysqlEnum("plan", ["free", "founder", "team"]).notNull(),
  status: varchar("status", { length: 64 }).notNull(),
  testMode: int("testMode").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
