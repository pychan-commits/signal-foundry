CREATE TABLE `customer_segments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`name` varchar(140) NOT NULL,
	`description` text,
	`color` varchar(16) NOT NULL DEFAULT '#4F46E5',
	`audienceSize` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `customer_segments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `customers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`segmentId` int,
	`name` varchar(160) NOT NULL,
	`email` varchar(320),
	`company` varchar(160),
	`title` varchar(160),
	`status` enum('active','prospect','inactive') NOT NULL DEFAULT 'active',
	`lifetimeValue` int NOT NULL DEFAULT 0,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `customers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `decisions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`opportunityId` int,
	`title` varchar(240) NOT NULL,
	`outcome` enum('build','test','investigate','defer','decline') NOT NULL,
	`reasoning` text NOT NULL,
	`evidence` text,
	`decidedBy` varchar(160) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `decisions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `experiments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`opportunityId` int,
	`title` varchar(240) NOT NULL,
	`hypothesis` text NOT NULL,
	`method` varchar(160) NOT NULL,
	`successMetric` text NOT NULL,
	`result` text,
	`status` enum('planned','running','complete','inconclusive') NOT NULL DEFAULT 'planned',
	`dueDate` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `experiments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `notes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`entityType` varchar(80) NOT NULL,
	`entityId` int,
	`body` text NOT NULL,
	`createdBy` varchar(160),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `opportunities` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`problemId` int,
	`title` varchar(240) NOT NULL,
	`description` text,
	`segment` varchar(160),
	`frequency` int NOT NULL DEFAULT 3,
	`severity` int NOT NULL DEFAULT 3,
	`willingnessToPay` int NOT NULL DEFAULT 3,
	`strategicFit` int NOT NULL DEFAULT 3,
	`effort` int NOT NULL DEFAULT 3,
	`status` enum('backlog','considering','testing','planned','shipped') NOT NULL DEFAULT 'backlog',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `opportunities_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `problem_signals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`problemId` int NOT NULL,
	`signalId` int NOT NULL,
	CONSTRAINT `problem_signals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `problems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`title` varchar(240) NOT NULL,
	`summary` text,
	`status` enum('emerging','validated','watching','resolved') NOT NULL DEFAULT 'emerging',
	`frequency` int NOT NULL DEFAULT 3,
	`severity` int NOT NULL DEFAULT 3,
	`owner` varchar(160),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `problems_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `saved_views` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`name` varchar(140) NOT NULL,
	`entityType` varchar(80) NOT NULL,
	`filterJson` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `saved_views_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `signal_tags` (
	`id` int AUTO_INCREMENT NOT NULL,
	`signalId` int NOT NULL,
	`tagId` int NOT NULL,
	CONSTRAINT `signal_tags_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `signals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`customerId` int,
	`segmentId` int,
	`title` varchar(240) NOT NULL,
	`detail` text,
	`source` enum('interview','support','sales','feature_request','survey','other') NOT NULL DEFAULT 'interview',
	`urgency` enum('low','medium','high','critical') NOT NULL DEFAULT 'medium',
	`status` enum('new','reviewing','linked','archived') NOT NULL DEFAULT 'new',
	`productArea` varchar(120) NOT NULL DEFAULT 'Core product',
	`evidenceStrength` int NOT NULL DEFAULT 3,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `signals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `subscriptions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`plan` enum('free','founder','team') NOT NULL,
	`status` enum('test_active','cancelled') NOT NULL DEFAULT 'test_active',
	`paymentProvider` varchar(64) NOT NULL DEFAULT 'test_checkout',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `subscriptions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `tags` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`name` varchar(80) NOT NULL,
	`color` varchar(16) NOT NULL DEFAULT '#818CF8',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `tags_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `user_sessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`tokenHash` varchar(128) NOT NULL,
	`expiresAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `user_sessions_id` PRIMARY KEY(`id`),
	CONSTRAINT `user_sessions_tokenHash_unique` UNIQUE(`tokenHash`)
);
--> statement-breakpoint
CREATE TABLE `workspace_members` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`userId` int,
	`displayName` varchar(160) NOT NULL,
	`email` varchar(320) NOT NULL,
	`role` enum('owner','admin','member') NOT NULL DEFAULT 'member',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `workspace_members_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `workspaces` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(140) NOT NULL,
	`slug` varchar(160) NOT NULL,
	`plan` enum('free','founder','team') NOT NULL DEFAULT 'free',
	`scoringWeights` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `workspaces_id` PRIMARY KEY(`id`),
	CONSTRAINT `workspaces_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `openId` varchar(96) NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `passwordHash` varchar(255);--> statement-breakpoint
ALTER TABLE `users` ADD `currentWorkspaceId` int;--> statement-breakpoint
ALTER TABLE `users` ADD `passwordResetTokenHash` varchar(128);--> statement-breakpoint
ALTER TABLE `users` ADD `passwordResetExpiresAt` timestamp;--> statement-breakpoint
ALTER TABLE `users` ADD CONSTRAINT `users_email_unique` UNIQUE(`email`);