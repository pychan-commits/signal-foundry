CREATE TABLE `anonymous_sessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`publicId` varchar(64) NOT NULL,
	`tokenHash` varchar(128) NOT NULL,
	`noticeVersion` varchar(32) NOT NULL DEFAULT '2026-10-v1',
	`noticeAcknowledgedAt` timestamp,
	`analyticsConsent` enum('unknown','granted','withdrawn') NOT NULL DEFAULT 'unknown',
	`analyticsConsentAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`lastSeenAt` timestamp NOT NULL DEFAULT (now()),
	`expiresAt` timestamp NOT NULL,
	CONSTRAINT `anonymous_sessions_id` PRIMARY KEY(`id`),
	CONSTRAINT `anonymous_sessions_publicId_unique` UNIQUE(`publicId`),
	CONSTRAINT `anonymous_sessions_tokenHash_unique` UNIQUE(`tokenHash`)
);
--> statement-breakpoint
ALTER TABLE `workspaces` ADD `anonymousSessionId` int;