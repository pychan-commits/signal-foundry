CREATE TABLE `billing_entitlements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`stripeCustomerId` varchar(240),
	`stripeSubscriptionId` varchar(240),
	`plan` enum('free','founder','team') NOT NULL,
	`status` varchar(64) NOT NULL,
	`testMode` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `billing_entitlements_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `signal_attachments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`signalId` int NOT NULL,
	`providerFileId` varchar(240) NOT NULL,
	`fileName` varchar(240) NOT NULL,
	`url` text NOT NULL,
	`mimeType` varchar(120) NOT NULL,
	`fileSize` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `signal_attachments_id` PRIMARY KEY(`id`)
);
